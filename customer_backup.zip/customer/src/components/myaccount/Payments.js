import React from 'react';
import { Row, Col, Button } from 'react-bootstrap';
import PaymentCard from '../common/PaymentCard';
import DeleteAddressModal from '../modals/DeleteAddressModal';
import AddAddressModal from '../modals/AddAddressModal';
import EditAddressModal from '../modals/EditAddressModal';
import SERVER_PREFIX from '../ServerConfig';

class Payments extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.state = {
      showDeleteModal: false,
      creditCards: [],
    };
  }
  componentDidMount() {
    this.reloadData();
  }

  reloadData() {
    setTimeout(
      fetch(SERVER_PREFIX + '/customers/creditcards/' + localStorage.getItem('loggedInUserId'))
        .then((res) => res.json())
        .then(
          (result) => {
            this.setState({
              isLoaded: true,
              creditCards: result,
            });
          },
          // Note: it's important to handle errors here
          // instead of a catch() block so that we don't swallow
          // exceptions from actual bugs in components.
          (error) => {
            this.setState({
              isLoaded: true,
              error,
            });
          }
        ),
      1
    );
  }

  hideDeleteModal = () => this.setState({ showDeleteModal: false });

  render() {
    return (
      <>
        <AddAddressModal show={this.state.showAddModal} onHide={this.hideAddModal} />
        <DeleteAddressModal show={this.state.showDeleteModal} onHide={this.hideDeleteModal} />
        <EditAddressModal show={this.state.showEditModal} onHide={this.hideEditModal} />
        <div className="p-4 bg-white shadow-sm">
          <Row>
            <Col md={9}>
              <h4 className="font-weight-bold mt-0 mb-3">Credit Cards</h4>
            </Col>
            <Col md={3}>
              <Button
                onClick={() => this.setState({ showAddressModal: true })}
                type="button"
                variant="primary"
                className="text-center justify-content-center"
              >
                Add Credit Card
              </Button>
            </Col>
            <Col md={12}>
              {this.state.creditCards.map((item) => {
                return (
                  <PaymentCard
                    title={item.creditcardnumber}
                    name={item.creditcardname}
                    imageclassName="mr-3"
                    subTitle={'Valid Until: ' + item.expirymonth + '/' + item.expiryyear}
                    onClick={() => this.setState({ showDeleteModal: true })}
                  />
                );
              })}
            </Col>
          </Row>
        </div>
      </>
    );
  }
}
export default Payments;
