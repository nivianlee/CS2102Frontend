const SERVER_PREFIX = "http://localhost:3000";

export default SERVER_PREFIX;
